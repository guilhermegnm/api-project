How to deploy:

1. Type "serverless deploy" to deploy the api to AWS Lambda

How to save on Git:

1. git add .
2. git commit -m "<commit_name>"
3. git push -u origin main
    3a. if needed: git pull origin main 