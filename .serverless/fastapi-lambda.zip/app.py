# %%
from bs4 import BeautifulSoup
import requests
from lxml import etree
import logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from mangum import Mangum # type: ignore

# %% [markdown]
# ### 1. Auxiliar functions

# %%
def extract_source(url):
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0'}
        source=requests.get(url, headers=headers).text
        return source

def extract_data(source):
    soup = BeautifulSoup(source)
    return soup

# %% [markdown]
# ### 2. Get product info

# %%
def get_title(soup):
    title_string = '//*[@id="start-of-content"]/div[1]/div/div/div/article/div/div/div[2]/div[1]/h1/span/text()[1]'
    title = etree.HTML(str(soup)).xpath(title_string)[0]
    return title

def get_price(soup):
    price_string = '//*[@id="start-of-content"]/div[1]/div/div/div/article/div/div/div[2]/div[2]/div[1]/div/span/text()[1]'
    price_kg_string = '//*[@id="start-of-content"]/div[1]/div/div/div/article/div/div/div[2]/div[1]/div/span/text()[6]'

    price_dict = {
        "price_euro": float(''.join(value for value in etree.HTML(str(soup)).xpath(price_string))),
        "price_euro_kg": float(etree.HTML(str(soup)).xpath(price_kg_string)[0].replace(",", "."))
    }

    return price_dict

def get_weight(soup):
    weight_string = '//*[@id="start-of-content"]/div[1]/div/div/div/article/div/div/div[2]/div[1]/div/text()[1]'
    weight = etree.HTML(str(soup)).xpath(weight_string)[0]
    return weight

def get_nutrition(soup):

    nutrition_table_string_prefix = '//*[@id="start-of-content"]/div[2]/div/div[1]/div[1]/div[3]/table/tbody/'
    nutrition_table_size = len(etree.HTML(str(soup)).xpath('//*[@id="start-of-content"]/div[2]/div/div[1]/div[1]/div[3]/table/tbody')[0])

    nutrition_dict = {etree.HTML(str(soup)).xpath(f'{nutrition_table_string_prefix}tr[{i+1}]/td[1]')[0].text: etree.HTML(str(soup)).xpath(f'{nutrition_table_string_prefix}tr[{i+1}]/td[2]')[0].text for i in range(nutrition_table_size)}

    return nutrition_dict

def get_item(url):

    soup = extract_data(extract_source(url))

    item_dict = {
        "title": get_title(soup),
        "price": get_price(soup),
        "weight": get_weight(soup),
        "nutrition": get_nutrition(soup)
    }

    return item_dict

# %%
# url = "https://www.ah.nl/producten/product/wi192851/bimi"
# item = get_item(url)
# item

# %%
# description1_string = '//*[@id="start-of-content"]/div[1]/div/div/div/article/div/div/div[2]/div[4]/div[2]'
# description2_string = '//*[@id="start-of-content"]/div[2]/div/div[1]/div[1]/div[1]/div[1]/div'
# extras_string = '//*[@id="start-of-content"]/div[2]/div/div[1]/div[1]/div[1]/div[1]/div/p/text()'


# %%
# Create a FastAPI instance
app = FastAPI()

# Define a Pydantic model for the input
class URLRequest(BaseModel):
    url: str

# Define an API endpoint
@app.post("/")
def process_url_endpoint(request: URLRequest):
    try:
        # Call your existing function
        result = get_item(request.url)
        return {"success": True, "data": result}
    except Exception as e:
        logging.error(f"Error processing URL: {str(e)}")
        raise HTTPException(status_code=500, detail="deu erro")

# %%
handler = Mangum(app)